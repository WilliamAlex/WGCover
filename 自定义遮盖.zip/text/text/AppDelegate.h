//
//  AppDelegate.h
//  text
//
//  Created by Alex on 2017/2/24.
//  Copyright © 2017年 ShenZhenQinJin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

