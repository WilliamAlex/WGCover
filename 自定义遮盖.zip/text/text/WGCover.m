//
//  WGCover.m
//  text
//
//  Created by Alex on 2017/2/24.
//  Copyright © 2017年 ShenZhenQinJin. All rights reserved.
//

#import "WGCover.h"
#import "UIView+GKExtension.h"


static WGCover   *_cover;
static UIView    *_fromView;
static UIView    *_contentView;
static BOOL      _animated;
static showBlock _showBlock;
static hideBlock _hideBlock;
static BOOL      _notclick;
@implementation WGCover

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        // 自动伸缩
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        
        _animated = NO;
    }
    return self;
}

+ (instancetype)cover
{
    return [[self alloc] init];
}

+ (instancetype)translucentCoverWithTarget:(id)target action:(SEL)action
{
    WGCover *cover = [self cover];
    cover.backgroundColor = [UIColor blackColor];
    cover.alpha = 0.5;
    [cover addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:target action:action]];
    return cover;
}

// 半透明的block
+ (void)translucentCoverFrom:(UIView *)fromView content:(UIView *)contentView aanimated:(BOOL)animated showBlock:(showBlock)show hideBlock:(hideBlock)hide
{
    [self translucentCoverFrom:fromView content:contentView animated:animated notClick:NO showBlock:show hideBlock:hide];
}


/**
 显示一个半透明的遮盖

 @param fromView 显示到哪个View
 @param contentView 遮盖上显示的View
 @param animated 是否有动画, 默认是NO
 @param notClick 是否能点击, 默认是NO
 @param showBlock 显示时block
 @param hideBlock 隐藏时的block
 */
+ (void)translucentCoverFrom:(UIView *)fromView content:(UIView *)contentView animated:(BOOL)animated notClick:(BOOL)notClick showBlock:(showBlock)showBlock hideBlock:(hideBlock)hideBlock
{
    
    // 创建遮盖
    WGCover *cover = [self cover];
    
    // 设置颜色和大小
    cover.frame = fromView.bounds;
    cover.backgroundColor = [UIColor blackColor];
    cover.alpha = 0.5;
    [fromView addSubview:cover];
    _cover = cover;
    
    // 判断遮盖能否可以点击
    if (!notClick) {
        
        [cover addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hide)]];
    }
    
    // 赋值
    _fromView = fromView;
    _contentView = contentView;
    _animated = animated;
    _notclick = notClick;
    _showBlock = showBlock;
    _hideBlock = hideBlock;
    
    // 显示内容
    [self showContentView];
}

+ (void) showContentView {

        [_fromView addSubview:_contentView];
        [self show];
}


// 显示
+ (void)show
{
    if (_animated) {
        _contentView.gk_y = KScreenH;
        [UIView animateWithDuration:0.25 animations:^{
            _contentView.gk_y = KScreenH - _contentView.gk_height;
        }completion:^(BOOL finished) {
            !_showBlock ? : _showBlock();
        }];
    }else{
        !_showBlock ? : _showBlock();
        _contentView.gk_y = KScreenH - _contentView.gk_height;
    }
}

// 隐藏
+ (void)hide{
    if (_animated && ![_fromView isKindOfClass:[UIWindow class]]) {
        
        [UIView animateWithDuration:0.25 animations:^{
            _contentView.gk_y = KScreenH;
        }completion:^(BOOL finished) {
            [_cover removeFromSuperview];
            [_contentView removeFromSuperview];
            !_hideBlock ? : _hideBlock();
        }];
    }else{
        [_cover removeFromSuperview];
        [_contentView removeFromSuperview];
        !_hideBlock ? : _hideBlock();
    }
}


@end



































