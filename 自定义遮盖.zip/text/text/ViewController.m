//
//  ViewController.m
//  text
//
//  Created by Alex on 2017/2/24.
//  Copyright © 2017年 ShenZhenQinJin. All rights reserved.
//

#import "ViewController.h"
#import "UIView+GKExtension.h"
#import "WGCover.h"

#define KScreenW [UIScreen mainScreen].bounds.size.width
#define KScreenH [UIScreen mainScreen].bounds.size.height
@interface ViewController ()

// 自定义遮盖
@property (nonatomic, weak) WGCover *cover;

// 弹出来的视图
@property (nonatomic, weak) UIView *customView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)button2:(id)sender {
    
    UIView *customView = [[UIView alloc] init];
    customView.gk_size = CGSizeMake(KScreenW, 300);
    customView.backgroundColor = [UIColor yellowColor];
    
    UILabel *label = [[UILabel alloc] init];
    label.text = @"弹窗显示了，6不6";
    label.frame = CGRectMake(30, 20, 300, 20);
    label.backgroundColor = [UIColor greenColor];
    label.textColor = [UIColor whiteColor];
    [customView addSubview:label];
    
    [WGCover translucentCoverFrom:self.view content:customView aanimated:YES showBlock:^{
        
        // 显示
    NSLog(@"弹窗显示了，6不6");
    } hideBlock:^{
        
        // 移除后的block
      NSLog(@"弹窗消失了，555");
        [customView removeFromSuperview];
    }];
}


- (IBAction)button1:(id)sender {
    
    WGCover *cover = [WGCover translucentCoverWithTarget:self action:@selector(hidden)];
    cover.alpha = 0.3;
    cover.frame = self.view.bounds;
    [self.view addSubview:cover];
    self.cover = cover;
    
    UIView *customView = [[UIView alloc] init];
    customView.backgroundColor = [UIColor greenColor];
    customView.frame = CGRectMake(0, KScreenH, KScreenW, 300);
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"就是这么简单" forState: UIControlStateNormal];
    button.backgroundColor = [UIColor redColor];
    button.frame = CGRectMake(100, 30, 100, 20);
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [customView addSubview:button];
    
    [self.view addSubview:customView];
    self.customView = customView;
    
    [UIView animateWithDuration:0.25 animations:^{
        
        customView.gk_y = KScreenH - 300;
    }];
    
}

- (void)hidden{
    [UIView animateWithDuration:0.25 animations:^{
        self.customView.gk_y = KScreenH;
    }completion:^(BOOL finished) {
        [self.cover removeFromSuperview];
        [self.customView removeFromSuperview];
    }];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
