//
//  WGCover.h
//  text
//
//  Created by Alex on 2017/2/24.
//  Copyright © 2017年 ShenZhenQinJin. All rights reserved.
//

#import <UIKit/UIKit.h>

#define KScreenW [UIScreen mainScreen].bounds.size.width
#define KScreenH [UIScreen mainScreen].bounds.size.height

typedef void(^showBlock)();
typedef void(^hideBlock)();

@interface WGCover : UIView

+ (instancetype)cover;

// 半透明的遮盖方法
+ (instancetype)translucentCoverWithTarget:(id)target action:(SEL)action;


/**
 半透明遮盖

 @param fromView 显示到哪个View
 @param contentView 展示哪个View
 @param animated 是否有动画
 @param show 显示
 @param hide 隐藏
 */
+ (void)translucentCoverFrom:(UIView *)fromView content:(UIView *)contentView aanimated:(BOOL)animated showBlock:(showBlock)show hideBlock:(hideBlock)hide;

@end
